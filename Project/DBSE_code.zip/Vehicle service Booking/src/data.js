export const vehicles = [
  { id: 1, name: 'Hyundai Creta', reg: 'TS 09 EF 4821', year: '2022', fuel: 'Petrol', last: '12 Aug 2024', next: '10 Nov 2024', color: 'sand' },
  { id: 2, name: 'Honda Activa 6G', reg: 'TS 08 HK 7290', year: '2021', fuel: 'Petrol', last: '02 Jul 2024', next: '02 Jan 2025', color: 'blue' },
]

export const centers = [
  { name: 'Autovista Miyapur', location: 'Miyapur, Hyderabad', distance: '4.8 km', rating: '4.8', slots: '6 slots today', services: ['Periodic service', 'AC repair', 'Wheel care'], hours: '08:00 - 20:00' },
  { name: 'Pitlane Motors', location: 'Kondapur, Hyderabad', distance: '7.2 km', rating: '4.6', slots: '3 slots today', services: ['Body work', 'Detailing', 'Engine care'], hours: '09:00 - 19:00' },
  { name: 'Bosch Car Service', location: 'Kukatpally, Hyderabad', distance: '9.1 km', rating: '4.7', slots: 'Tomorrow onwards', services: ['Periodic service', 'Diagnostics', 'Tyres'], hours: '08:30 - 19:30' },
]

export const bookings = [
  { id: 'BK-24091', vehicle: 'Hyundai Creta', service: 'Full car service', center: 'Autovista Miyapur', date: '24 Sep 2024', time: '10:30 AM', status: 'Confirmed' },
  { id: 'BK-24063', vehicle: 'Honda Activa 6G', service: 'Oil change', center: 'Pitlane Motors', date: '02 Jul 2024', time: '04:00 PM', status: 'Completed' },
]

export const reminders = [
  { title: 'Engine oil change', vehicle: 'Hyundai Creta', due: 'Due in 12 days', tone: 'amber', icon: 'droplet' },
  { title: 'Wheel alignment', vehicle: 'Honda Activa 6G', due: 'Due in 28 days', tone: 'teal', icon: 'disc' },
]

export const notifications = [
  { title: 'Booking confirmed', text: 'Your Creta service is confirmed for 24 Sep.', time: '12 min ago', unread: true },
  { title: 'Inspection completed', text: 'Autovista has shared your inspection report.', time: 'Yesterday', unread: true },
  { title: 'Maintenance reminder', text: 'Your Activa is due for an oil change soon.', time: '2 days ago', unread: false },
]

export const jobs = [
  { id: 'JC-8834', vehicle: 'Hyundai Creta', customer: 'Sathish Kumar', status: 'In progress', tech: 'Vikram S.', eta: 'Today, 5:30 PM' },
  { id: 'JC-8829', vehicle: 'Honda City', customer: 'Meera Kapoor', status: 'Waiting approval', tech: 'Rohit N.', eta: 'Tomorrow, 11:00 AM' },
]
