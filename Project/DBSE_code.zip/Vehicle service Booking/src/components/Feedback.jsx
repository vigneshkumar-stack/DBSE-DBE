import { useEffect } from 'react'
import { Check, X } from 'lucide-react'

export function Modal({ title, children, onClose, actions }) {
  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [onClose])

  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
    <section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <header className="modal-header"><div><span className="eyebrow">Vehicle Service Booking</span><h2 id="modal-title">{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></header>
      <div className="modal-body">{children}</div>
      {actions && <footer className="modal-actions">{actions}</footer>}
    </section>
  </div>
}

export function Toast({ toast, onClose }) {
  useEffect(() => {
    if (!toast) return undefined
    const timer = window.setTimeout(onClose, 3200)
    return () => window.clearTimeout(timer)
  }, [toast, onClose])
  if (!toast) return null
  return <div className={`toast ${toast.tone || 'success'}`} role="status"><Check size={16} /><span>{toast.message}</span><button onClick={onClose} aria-label="Dismiss"><X size={14} /></button></div>
}

export function ConfirmModal({ title, message, onCancel, onConfirm }) {
  return <Modal title={title} onClose={onCancel} actions={<><button className="button secondary" onClick={onCancel}>Cancel</button><button className="button" onClick={onConfirm}>Confirm</button></>}><p className="muted">{message}</p></Modal>
}
