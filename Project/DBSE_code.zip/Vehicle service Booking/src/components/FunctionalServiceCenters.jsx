import { useState } from 'react'
import { Clock3, MapPin, MoreHorizontal, Star, Wrench } from 'lucide-react'
import { centers } from '../data.js'
import { Modal } from './Feedback.jsx'

export function FunctionalServiceCenters({ navigate }) {
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(null)
  const filtered = centers.filter((center) => `${center.name} ${center.location} ${center.services.join(' ')}`.toLowerCase().includes(query.toLowerCase()))
  return <>
    <div className="page-heading"><div><span className="eyebrow">Vehicle Service Booking & Tracking System</span><h1>Service centers</h1></div><button className="button secondary" onClick={() => setQuery('')}><MapPin size={16} /> Patancheru, Hyderabad</button></div>
    <div className="filter-bar"><label className="search wide"><MapPin size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by center or area" /></label><span className="result-count">{filtered.length} centers near you</span></div>
    <div className="center-layout"><div className="center-list">{filtered.map((center) => <section className="card center-card" key={center.name}><div className="center-card-head"><div className="center-logo"><Wrench size={20} /></div><div><h3>{center.name}</h3><span><MapPin size={13} /> {center.location} · {center.distance}</span></div><button className="more" onClick={() => setSelected(center)} aria-label={`View ${center.name}`}><MoreHorizontal size={18} /></button></div><div className="rating"><Star size={15} fill="currentColor" /> <b>{center.rating}</b> <span>Excellent</span><span className="status teal">{center.slots}</span></div><div className="service-tags">{center.services.map((service) => <span key={service}>{service}</span>)}</div><div className="center-foot"><span><Clock3 size={14} /> {center.hours}</span><div><button className="button secondary" onClick={() => setSelected(center)}>View details</button><button className="button" onClick={() => navigate('/customer/book-service', { state: { center } })}>Book service</button></div></div></section>)}</div><div className="map-placeholder"><div className="map-label"><MapPin size={16} /> Showing centers near <b>Patancheru</b></div><div className="map-road road-one" /><div className="map-road road-two" /><div className="map-pin pin-one"><Wrench size={13} /></div><div className="map-pin pin-two"><Wrench size={13} /></div><div className="map-pin pin-three"><Wrench size={13} /></div><div className="you-pin">You</div></div></div>
    {selected && <Modal title={selected.name} onClose={() => setSelected(null)} actions={<button className="button" onClick={() => navigate('/customer/book-service', { state: { center: selected } })}>Book service</button>}><div className="detail-list"><div className="detail"><span>Location</span><b>{selected.location} · {selected.distance}</b></div><div className="detail"><span>Rating</span><b>{selected.rating} · Excellent</b></div><div className="detail"><span>Hours</span><b>{selected.hours}</b></div><div className="detail"><span>Services</span><b>{selected.services.join(', ')}</b></div></div></Modal>}
  </>
}
