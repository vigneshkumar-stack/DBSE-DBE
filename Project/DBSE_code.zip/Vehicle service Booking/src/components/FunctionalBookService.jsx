import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import { ChevronRight, ShieldCheck } from 'lucide-react'
import { bookings, centers, vehicles } from '../data.js'
import { getBookings, getVehicles, normalizeVehicle, saveBookings, vehicleName } from '../utils/localData.js'

export function FunctionalBookService({ navigate }) {
  const location = useLocation()
  const savedVehicles = getVehicles(vehicles).map(normalizeVehicle)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    vehicleId: location.state?.vehicle?.id || savedVehicles[0]?.id || '',
    service: location.state?.service || 'Full car service',
    center: location.state?.center?.name || centers[0].name,
    date: '', time: '', pickup: false, drop: false, pickupLocation: '', dropLocation: '', notes: '',
  })
  const update = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.type === 'checkbox' ? event.target.checked : event.target.value }))
  const submit = (event) => {
    event.preventDefault()
    if (!form.vehicleId || !form.date || !form.time) return setError('Select a vehicle, date, and available time slot.')
    if (form.pickup && !form.pickupLocation.trim()) return setError('Enter the pickup location.')
    if (form.drop && !form.dropLocation.trim()) return setError('Enter the drop-off location.')
    const vehicle = savedVehicles.find((item) => String(item.id) === String(form.vehicleId))
    saveBookings([...getBookings(bookings), { id: `BK-${String(Date.now()).slice(-5)}`, vehicle: vehicleName(vehicle), service: form.service, center: form.center, date: form.date, time: form.time, status: 'Confirmed', vehicleId: vehicle.id, pickup: form.pickup, drop: form.drop, pickupLocation: form.pickupLocation.trim(), dropLocation: form.dropLocation.trim(), notes: form.notes }])
    navigate('/customer/bookings')
  }
  const selectedVehicle = savedVehicles.find((item) => String(item.id) === String(form.vehicleId))
  return <>
    <div className="page-heading"><div><span className="eyebrow">A few steps to a smoother drive</span><h1>Book a service</h1></div><span className="save-note"><ShieldCheck size={15} /> No payment required now</span></div>
    <form className="booking-layout" onSubmit={submit}>
      <section className="card booking-card">
        <div className="booking-form">
          <span className="eyebrow">Service appointment</span><h2>Tell us what your vehicle needs</h2><p className="muted">Choose the appointment details and confirm when you are ready.</p>
          <div className="selection-summary">
            <label className="form-field">Vehicle<select name="vehicleId" value={form.vehicleId} onChange={update}>{savedVehicles.map((vehicle) => <option key={vehicle.id} value={vehicle.id}>{vehicleName(vehicle)} · {vehicle.registrationNumber}</option>)}</select></label>
            <label className="form-field">Service<select name="service" value={form.service} onChange={update}>{['Full car service', 'Oil change', 'AC & cooling', 'Brake inspection'].map((item) => <option key={item}>{item}</option>)}</select></label>
            <label className="form-field">Service center<select name="center" value={form.center} onChange={update}>{centers.map((center) => <option key={center.name}>{center.name}</option>)}</select></label>
            <div className="booking-input-grid"><label className="form-field">Preferred date<input required type="date" name="date" value={form.date} onChange={update} min={new Date().toISOString().slice(0, 10)} /></label><label className="form-field">Available time<select required name="time" value={form.time} onChange={update}><option value="">Select a slot</option><option>09:00 AM</option><option>10:30 AM</option><option>02:00 PM</option><option>04:00 PM</option></select></label></div>
            <div className="toggle-row"><label><input type="checkbox" name="pickup" checked={form.pickup} onChange={update} /> Pickup required</label><label><input type="checkbox" name="drop" checked={form.drop} onChange={update} /> Drop-off required</label></div>
            <div className="booking-input-grid"><label className="form-field">Pickup location<input name="pickupLocation" value={form.pickupLocation} onChange={update} placeholder="Enter pickup address" required={form.pickup} /></label><label className="form-field">Drop-off location<input name="dropLocation" value={form.dropLocation} onChange={update} placeholder="Enter drop-off address" required={form.drop} /></label></div>
            <label className="form-field">Notes for the service center<textarea name="notes" value={form.notes} onChange={update} placeholder="Anything we should know?" /></label>
          </div>
        </div>
        <div className="form-actions"><button className="button secondary" type="button" onClick={() => navigate(-1)}>Cancel</button><button className="button" type="submit">Confirm booking <ChevronRight size={16} /></button></div>
        {error && <p className="auth-error form-error">{error}</p>}
      </section>
      <section className="card booking-summary"><span className="eyebrow">Booking summary</span><h3>{selectedVehicle ? vehicleName(selectedVehicle) : 'Select a vehicle'}</h3><p>{form.center}</p><hr /><div><span>Service</span><b>{form.service}</b></div><div><span>Appointment</span><b>{form.date && form.time ? `${form.date} · ${form.time}` : 'To be selected'}</b></div><div><span>Pickup & drop</span><b>{form.pickup || form.drop ? 'Included' : 'Not selected'}</b></div></section>
    </form>
  </>
}
