const VEHICLES_KEY = 'vehicle-service-booking.vehicles'
const BOOKINGS_KEY = 'vehicle-service-booking.bookings'
const REMINDERS_KEY = 'vehicle-service-booking.reminders'
const NOTIFICATIONS_KEY = 'vehicle-service-booking.notifications'
const PROFILE_KEY = 'vehicle-service-booking.profile'

function read(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key))
    return value ?? fallback
  } catch {
    return fallback
  }
}

function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
  return value
}

export function getVehicles(seed) {
  const saved = read(VEHICLES_KEY, null)
  if (saved) return saved
  return write(VEHICLES_KEY, seed)
}

export function saveVehicles(vehicles) {
  return write(VEHICLES_KEY, vehicles)
}

export function getBookings(seed) {
  return read(BOOKINGS_KEY, seed)
}

export function saveBookings(bookings) {
  return write(BOOKINGS_KEY, bookings)
}

export function getReminders(seed) {
  return read(REMINDERS_KEY, seed)
}

export function saveReminders(reminders) {
  return write(REMINDERS_KEY, reminders)
}

export function getNotifications(seed) {
  return read(NOTIFICATIONS_KEY, seed)
}

export function saveNotifications(notifications) {
  return write(NOTIFICATIONS_KEY, notifications)
}

export function getProfile(seed) {
  return read(PROFILE_KEY, seed)
}

export function saveProfile(profile) {
  return write(PROFILE_KEY, profile)
}

export function vehicleName(vehicle) {
  return [vehicle.brand, vehicle.model].filter(Boolean).join(' ') || vehicle.name || 'Vehicle'
}

export function normalizeVehicle(vehicle) {
  return {
    ...vehicle,
    name: vehicleName(vehicle),
    brand: vehicle.brand || vehicle.name?.split(' ')[0] || '',
    model: vehicle.model || vehicle.name?.split(' ').slice(1).join(' ') || '',
    reg: vehicle.reg || vehicle.registrationNumber || '',
    registrationNumber: vehicle.registrationNumber || vehicle.reg || '',
    year: String(vehicle.year || vehicle.modelYear || ''),
    modelYear: String(vehicle.modelYear || vehicle.year || ''),
    fuel: vehicle.fuel || vehicle.fuelType || '',
    fuelType: vehicle.fuelType || vehicle.fuel || '',
    color: vehicle.color || '',
    mileage: Number(vehicle.mileage || 0),
    type: vehicle.type || 'Car',
    status: vehicle.status || 'Active',
  }
}
