import { useState } from 'react'
import { ArrowRight, Car, Eye, EyeOff, LockKeyhole, Mail, Phone, ShieldCheck, UserRound, Wrench } from 'lucide-react'
import { Link } from 'react-router-dom'
import { login, signup } from './api/auth.js'

const panels = [['customer', 'Customer', 'Book and track your vehicle service', Car], ['service_center', 'Service Center', 'Manage vehicle servicing operations', Wrench]]
const adminPanel = ['admin', 'Administrator', 'Manage the entire service platform', ShieldCheck]

export function AuthPage({ mode, onSuccess }) {
  const isLogin = mode === 'login'
  const [panel, setPanel] = useState(null)
  const [showPassword, setShowPassword] = useState(false)
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', confirmPassword: '', role: 'CUSTOMER', terms: false, remember: true })
  const [errors, setErrors] = useState({})

  const update = (event) => {
    const { name, value, type, checked } = event.target
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }))
    setErrors((current) => ({ ...current, [name]: '' }))
  }

  const submit = (event) => {
    event.preventDefault()
    const nextErrors = {}
    if (!panel) nextErrors.panel = 'Select a panel to continue.'
    if (!form.email.trim()) nextErrors.email = 'Enter your email address.'
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) nextErrors.email = 'Enter a valid email address.'
    if (!form.password) nextErrors.password = 'Enter your password.'
    else if (form.password.length < 6) nextErrors.password = 'Use at least 6 characters.'
    if (!isLogin && !form.fullName.trim()) nextErrors.fullName = 'Enter your full name.'
    if (!isLogin && !form.phone.trim()) nextErrors.phone = 'Enter your phone number.'
    if (!isLogin && form.confirmPassword !== form.password) nextErrors.confirmPassword = 'Passwords do not match.'
    if (!isLogin && !form.terms) nextErrors.terms = 'Accept the terms to continue.'
    if (Object.keys(nextErrors).length) return setErrors(nextErrors)
    onSuccess(isLogin ? login({ ...form, panel }) : signup({ ...form, panel }))
  }

  return <main className="auth-page">
    <section className="auth-showcase">
      <div className="auth-brand"><span className="auth-brand-mark"><Wrench size={18} /></span><span>Vehicle Service Booking &amp; Tracking System</span></div>
      <div className="auth-showcase-copy"><h1>Vehicle Service Booking &amp; Tracking System</h1></div>
      <div className="auth-road"><span /><span /><span /></div>
      <div className="auth-trust"><ShieldCheck size={18} /><span><strong>Trusted service, every mile</strong><small>Secure account access for your entire garage</small></span></div>
    </section>
    <section className="auth-panel"><div className="auth-form-wrap">
      {!panel ? <PanelSelection mode={mode} onSelect={setPanel} /> : <>
      <button className="auth-back" type="button" onClick={() => setPanel(null)}>← Change panel</button>
      <div className="auth-heading"><span className="eyebrow">{isLogin ? `${panel === 'customer' ? 'Customer' : panel === 'admin' ? 'Administrator' : 'Service Center'} Login` : 'Create your account'}</span><h2>{panel === 'customer' ? 'Customer Login' : panel === 'admin' ? 'Administrator Login' : 'Service Center Login'}</h2><p>{isLogin ? 'Enter your details to continue.' : 'Choose the account type that fits your work.'}</p></div>
      <form className="auth-form" onSubmit={submit} noValidate>
        {!isLogin && <Field icon={UserRound} label="Full name" name="fullName" value={form.fullName} onChange={update} error={errors.fullName} placeholder="Sathish Kumar" />}
        <Field icon={Mail} label="Email address" name="email" type="email" value={form.email} onChange={update} error={errors.email} placeholder="you@example.com" />
        {!isLogin && <Field icon={Phone} label="Phone number" name="phone" type="tel" value={form.phone} onChange={update} error={errors.phone} placeholder="+91 98765 43210" />}
        <Field icon={LockKeyhole} label="Password" name="password" type={showPassword ? 'text' : 'password'} value={form.password} onChange={update} error={errors.password} placeholder="Enter your password" trailing={<button type="button" className="auth-icon-button" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button>} />
        {!isLogin && <Field icon={LockKeyhole} label="Confirm password" name="confirmPassword" type={showPassword ? 'text' : 'password'} value={form.confirmPassword} onChange={update} error={errors.confirmPassword} placeholder="Repeat your password" />}
        {isLogin ? <div className="auth-options"><label className="check-label"><input type="checkbox" name="remember" checked={form.remember} onChange={update} /> Remember me</label><button type="button" className="auth-link">Forgot password?</button></div> : <label className="check-label terms"><input type="checkbox" name="terms" checked={form.terms} onChange={update} /> I agree to the <button type="button" className="auth-link">terms & conditions</button></label>}
        {errors.terms && <p className="auth-error form-error">{errors.terms}</p>}
        <button className="auth-submit" type="submit">{isLogin ? 'Login to panel' : 'Create account'} <span>→</span></button>
      </form></>}
      <p className="auth-switch">{isLogin ? 'New here?' : 'Already have an account?'} <Link to={isLogin ? '/signup' : '/login'}>{isLogin ? 'Create an account' : 'Sign in'}</Link></p>
      {errors.panel && <p className="auth-error form-error">{errors.panel}</p>}
      <small className="mock-note">Demo mode · authentication is stored locally in this browser</small>
    </div></section>
  </main>
}

function PanelSelection({ mode, onSelect }) {
  const availablePanels = mode === 'login' ? [...panels, adminPanel] : panels
  return <div className="panel-selection"><div className="auth-heading"><span className="eyebrow">{mode === 'login' ? 'Welcome back' : 'Get started'}</span><h2>{mode === 'login' ? 'Select your panel' : 'Create your account'}</h2><p>Choose where you want to manage vehicle service.</p></div><div className="panel-options">{availablePanels.map(([value, label, description, Icon]) => <button type="button" className="panel-option" key={value} onClick={() => onSelect(value)}><span className="panel-icon"><Icon size={23} /></span><strong>{label}</strong><small>{description}</small><span className="panel-continue">Continue <ArrowRight size={14} /></span></button>)}</div></div>
}

function Field({ icon: Icon, label, name, value, onChange, error, trailing, ...props }) {
  return <label className="auth-field"><span className="auth-label">{label}</span><span className={`auth-input ${error ? 'has-error' : ''}`}><Icon size={16} /><input name={name} value={value} onChange={onChange} {...props} />{trailing}</span>{error && <small className="auth-error">{error}</small>}</label>
}
