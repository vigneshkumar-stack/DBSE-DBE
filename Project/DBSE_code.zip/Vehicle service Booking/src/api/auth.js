// Frontend-only auth boundary. Replace these functions with REST calls later.
const AUTH_STORAGE_KEY = 'smart-service-booking-tracking-desk.mockUser'

export function getStoredUser() {
  try {
    const user = JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY))
    if (user?.fullName === 'Arjun Reddy') {
      user.fullName = 'Sathish Kumar'
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user))
    }
    return user
  } catch {
    return null
  }
}

export function login(credentials) {
  const user = {
    id: 'mock-user-001',
    fullName: credentials.email.split('@')[0].replace(/[._-]/g, ' '),
    email: credentials.email,
    panel: credentials.panel || 'customer',
    role: credentials.panel === 'admin' ? 'ADMIN' : credentials.panel === 'service_center' ? 'SERVICE_ADVISOR' : 'CUSTOMER',
  }
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user))
  return user
}

export function signup(details) {
  const user = {
    id: `mock-user-${Date.now()}`,
    fullName: details.fullName,
    email: details.email,
    phone: details.phone,
    panel: details.panel || 'customer',
    role: details.panel === 'service_center' ? 'SERVICE_ADVISOR' : 'CUSTOMER',
  }
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user))
  return user
}

export function logout() {
  localStorage.removeItem(AUTH_STORAGE_KEY)
}
