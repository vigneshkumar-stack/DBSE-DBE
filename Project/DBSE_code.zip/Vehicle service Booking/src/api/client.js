// API boundary for future REST integration. Current screens use local mock data.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'

export async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!response.ok) throw new Error(`Request failed: ${response.status}`)
  return response.json()
}

export const vehicleApi = { list: () => request('/vehicles') }
export const bookingApi = { list: () => request('/bookings'), create: (payload) => request('/bookings', { method: 'POST', body: JSON.stringify(payload) }) }
export const serviceCenterApi = { list: () => request('/service-centers') }
export const notificationApi = { list: () => request('/notifications') }
