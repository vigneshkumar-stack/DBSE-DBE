import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { Role, User } from '../models/index.js'

const PUBLIC_ROLES = new Set(['CUSTOMER', 'SERVICE_CENTER'])
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function authError(message, statusCode = 400) {
  const error = new Error(message)
  error.statusCode = statusCode
  return error
}

function safeUser(user) {
  return {
    user_id: user.user_id,
    full_name: user.full_name,
    email: user.email,
    role: user.Role?.role_name || user.role?.role_name,
  }
}

function validateRegistration({ full_name, email, phone, password, role }) {
  if (!full_name || !email || !phone || !password || !role) {
    throw authError('full_name, email, phone, password and role are required')
  }
  if (!EMAIL_PATTERN.test(email)) throw authError('Please provide a valid email address')
  if (password.length < 8) throw authError('Password must be at least 8 characters long')
  if (!PUBLIC_ROLES.has(role)) {
    throw authError('Public registration is limited to CUSTOMER or SERVICE_CENTER')
  }
}

export async function registerUser(input) {
  const normalizedInput = {
    ...input,
    email: input.email?.trim().toLowerCase(),
    role: input.role?.trim().toUpperCase(),
  }
  validateRegistration(normalizedInput)

  const existingUser = await User.findOne({ where: { email: normalizedInput.email } })
  if (existingUser) throw authError('An account with this email already exists', 409)

  const roleName = normalizedInput.role === 'CUSTOMER' ? 'CUSTOMER' : 'SERVICE_ADVISOR'
  const role = await Role.findOne({ where: { role_name: roleName } })
  if (!role) throw authError(`Role ${roleName} was not found in the roles table`, 500)

  const passwordHash = await bcrypt.hash(normalizedInput.password, 12)
  const user = await User.create({
    role_id: role.role_id,
    service_center_id: null,
    full_name: normalizedInput.full_name.trim(),
    email: normalizedInput.email,
    phone: normalizedInput.phone.trim(),
    password_hash: passwordHash,
    is_active: true,
    created_at: new Date(),
  })

  user.Role = role
  return safeUser(user)
}

export async function loginUser({ email, password }) {
  if (!email || !password) throw authError('email and password are required')

  const user = await User.findOne({
    where: { email: email.trim().toLowerCase() },
    include: [{ model: Role, as: 'role', attributes: ['role_id', 'role_name'] }],
  })
  if (!user || !user.is_active) throw authError('Invalid email or password', 401)

  const passwordMatches = await bcrypt.compare(password, user.password_hash)
  if (!passwordMatches) throw authError('Invalid email or password', 401)
  if (!process.env.JWT_SECRET) throw authError('JWT secret is not configured', 500)

  const tokenPayload = {
    user_id: user.user_id,
    role_id: user.role_id,
    role_name: user.role.role_name,
  }
  const token = jwt.sign(tokenPayload, process.env.JWT_SECRET, { expiresIn: '1d' })

  return { token, user: safeUser(user) }
}