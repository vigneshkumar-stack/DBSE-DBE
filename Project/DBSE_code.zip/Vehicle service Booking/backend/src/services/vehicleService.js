import { UniqueConstraintError, ValidationError } from 'sequelize'
import Vehicle from '../models/Vehicle.js'

function serviceError(message, statusCode = 400) {
  const error = new Error(message)
  error.statusCode = statusCode
  return error
}

function validateVehicle(input) {
  const requiredFields = ['vehicle_type_id', 'brand', 'model', 'registration_number']
  if (requiredFields.some((field) => input[field] === undefined || input[field] === null || input[field] === '')) {
    throw serviceError('vehicle_type_id, brand, model and registration_number are required')
  }
  if (!Number.isInteger(Number(input.vehicle_type_id)) || Number(input.vehicle_type_id) < 1) {
    throw serviceError('vehicle_type_id must be a positive integer')
  }
  if (input.model_year !== undefined && input.model_year !== null && input.model_year !== '') {
    const year = Number(input.model_year)
    if (!Number.isInteger(year) || year < 1886 || year > new Date().getFullYear() + 1) throw serviceError('model_year must be a valid year')
  }
  if (input.mileage !== undefined && input.mileage !== null && input.mileage !== '') {
    if (!Number.isFinite(Number(input.mileage)) || Number(input.mileage) < 0) throw serviceError('mileage must be a valid non-negative number')
  }
}

function vehicleAttributes(input, userId) {
  return {
    user_id: userId,
    vehicle_type_id: Number(input.vehicle_type_id),
    brand: String(input.brand).trim(),
    model: String(input.model).trim(),
    registration_number: String(input.registration_number).trim().toUpperCase(),
    model_year: input.model_year === '' || input.model_year === undefined ? null : input.model_year,
    fuel_type: input.fuel_type || null,
    color: input.color || null,
    mileage: input.mileage === '' || input.mileage === undefined ? 0 : input.mileage,
  }
}

function mapDatabaseError(error) {
  if (error instanceof UniqueConstraintError) return serviceError('Registration number already exists', 409)
  if (error instanceof ValidationError) return serviceError('Vehicle data is invalid', 400)
  return error
}

export async function createVehicle(userId, input) {
  try {
    validateVehicle(input)
    return await Vehicle.create(vehicleAttributes(input, userId))
  } catch (error) {
    throw mapDatabaseError(error)
  }
}

export async function listVehicles(userId) {
  return Vehicle.findAll({ where: { user_id: userId }, order: [['vehicle_id', 'DESC']] })
}

export async function getVehicle(userId, vehicleId) {
  const vehicle = await Vehicle.findOne({ where: { vehicle_id: vehicleId, user_id: userId } })
  if (!vehicle) throw serviceError('Vehicle not found', 404)
  return vehicle
}

export async function updateVehicle(userId, vehicleId, input) {
  try {
    validateVehicle(input)
    const vehicle = await getVehicle(userId, vehicleId)
    await vehicle.update(vehicleAttributes(input, userId))
    return vehicle
  } catch (error) {
    throw mapDatabaseError(error)
  }
}

export async function deleteVehicle(userId, vehicleId) {
  const vehicle = await getVehicle(userId, vehicleId)
  await vehicle.destroy()
}
