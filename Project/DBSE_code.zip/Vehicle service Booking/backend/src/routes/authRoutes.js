import { Router } from 'express'
import { login, profile, register } from '../controllers/authController.js'
import { authenticateToken, authorizeRoles } from '../middleware/authMiddleware.js'

const router = Router()

router.post('/register', register)
router.post('/login', login)
router.get('/profile', authenticateToken, profile)
router.get('/customer-test', authenticateToken, authorizeRoles('CUSTOMER'), profile)
router.get('/service-center-test', authenticateToken, authorizeRoles('SERVICE_ADVISOR'), profile)

export default router