import { Router } from 'express'
import { create, getOne, list, remove, update } from '../controllers/vehicleController.js'
import { authenticateToken, authorizeRoles } from '../middleware/authMiddleware.js'

const router = Router()

router.use(authenticateToken, authorizeRoles('CUSTOMER'))
router.post('/', create)
router.get('/', list)
router.get('/:id', getOne)
router.put('/:id', update)
router.delete('/:id', remove)

export default router
