import { loginUser, registerUser } from '../services/authService.js'

export async function register(request, response, next) {
  try {
    const user = await registerUser(request.body)
    return response.status(201).json({ success: true, message: 'Registration successful', user })
  } catch (error) {
    return next(error)
  }
}

export async function login(request, response, next) {
  try {
    const { token, user } = await loginUser(request.body)
    return response.json({ success: true, message: 'Login successful', token, user })
  } catch (error) {
    return next(error)
  }
}

export function profile(request, response) {
  return response.json({ success: true, message: 'Authenticated user', user: request.user })
}