import { createVehicle, deleteVehicle, getVehicle, listVehicles, updateVehicle } from '../services/vehicleService.js'

export async function create(request, response, next) {
  try {
    const vehicle = await createVehicle(request.user.user_id, request.body)
    return response.status(201).json({ success: true, message: 'Vehicle created successfully', vehicle })
  } catch (error) {
    return next(error)
  }
}

export async function list(request, response, next) {
  try {
    const vehicles = await listVehicles(request.user.user_id)
    return response.json({ success: true, vehicles })
  } catch (error) {
    return next(error)
  }
}

export async function getOne(request, response, next) {
  try {
    const vehicle = await getVehicle(request.user.user_id, request.params.id)
    return response.json({ success: true, vehicle })
  } catch (error) {
    return next(error)
  }
}

export async function update(request, response, next) {
  try {
    const vehicle = await updateVehicle(request.user.user_id, request.params.id, request.body)
    return response.json({ success: true, message: 'Vehicle updated successfully', vehicle })
  } catch (error) {
    return next(error)
  }
}

export async function remove(request, response, next) {
  try {
    await deleteVehicle(request.user.user_id, request.params.id)
    return response.json({ success: true, message: 'Vehicle deleted successfully' })
  } catch (error) {
    return next(error)
  }
}
