import Role from './Role.js'
import User from './User.js'
import Vehicle from './Vehicle.js'

Role.hasMany(User, { foreignKey: 'role_id', as: 'users' })
User.belongsTo(Role, { foreignKey: 'role_id', as: 'role' })
User.hasMany(Vehicle, { foreignKey: 'user_id', as: 'vehicles' })
Vehicle.belongsTo(User, { foreignKey: 'user_id', as: 'owner' })

export { Role, User, Vehicle }