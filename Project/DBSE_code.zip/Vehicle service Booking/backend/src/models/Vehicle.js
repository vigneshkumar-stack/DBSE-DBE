import { DataTypes } from 'sequelize'
import sequelize from '../config/database.js'

const Vehicle = sequelize.define('Vehicle', {
  vehicle_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  vehicle_type_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  brand: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  model: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  registration_number: {
    type: DataTypes.STRING(30),
    allowNull: false,
  },
  model_year: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  fuel_type: {
    type: DataTypes.STRING(30),
    allowNull: true,
  },
  color: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  mileage: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
    defaultValue: 0,
  },
}, {
  tableName: 'vehicles',
  timestamps: false,
})

export default Vehicle
